This ZIP file contains Jonathan Geary's materials from his and Adam Ussishkin's workshop on "Priming methods in word recognition" at the 2019 LSA Linguistic Institute (2019-6-26; https://lsa2019.ucdavis.edu/priming-methods-in-word-recognition/). This file contains the following:

1) PDF copies of Jonathan's PowerPoint slides on (1) visual masked priming and (2) DMDX scripting.

2) A PDF copy of a list of papers that he referenced and that may be of interest to anyone planning to conduct visual masked priming research and/or use DMDX.

3) An EXE file containing a demonstration of different types of priming programmed in DMDX. Opening this file will launch DMDX, and since DMDX only works on Windows OS you need a Windows machine to run this file. *Since this is an EXE file, your anti-virus software may warn you against opening it (and downloading the ZIP file): It just contains a copy of DMDX and other files necessary to run the demonstration, nothing malicious.* If you cannot open this file, you can find non-DMDX demonstrations of visual masked priming (http://u.arizona.edu/~jonathangeary/visual_masked_priming.html) and auditory masked priming (http://u.arizona.edu/~jonathangeary/auditory_masked_priming.html) on his website.

4) Several sample DMDX scripts and an Excel document containing a sample stimulus list for a VMP experiment, plus associated files (namely, BMP files) needed to run the sample scripts.

Please contact Jonathan (jonathangeary@email.arizona.edu) with any questions.